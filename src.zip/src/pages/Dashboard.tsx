export interface DashboardProps {}

export default function Dashboard() {
  return <div></div>;
}
